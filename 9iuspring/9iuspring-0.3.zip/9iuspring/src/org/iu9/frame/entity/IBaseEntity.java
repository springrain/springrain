package org.iu9.frame.entity;
/**
 *  Entity的基础接口
 * @copyright {@link 9iu.org}
 * @author 9iuspring<9iuorg@gmail.com>
 * @version  2013-03-19 11:08:15
 * @see org.iu9.frame.entity.IBaseEntity
 */
public interface IBaseEntity extends java.io.Serializable {

}
