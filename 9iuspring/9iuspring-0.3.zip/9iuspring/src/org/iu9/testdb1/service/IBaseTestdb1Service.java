package org.iu9.testdb1.service;

import org.iu9.frame.service.IBaseService;


public interface IBaseTestdb1Service extends IBaseService {

}