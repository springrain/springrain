/**
 * auditlog 页面使用javascript
 * @copyright {@link 9iu.org}
 * @author 9iuspring<Auto generate>
 * @version  2013-05-09 15:29:15
 */


jQuery(document).ready(function(){
    
});


function submitUpdateForm(){
var flag=jQuery("#updateForm").form("validate");
if(flag){
submitForm("updateForm");
}

}
